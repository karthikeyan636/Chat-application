from django.contrib import admin
from .models import Chamber,Message
# Register your models here.
admin.site.register(Chamber)
admin.site.register(Message) 
