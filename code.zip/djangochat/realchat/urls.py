from django.urls import path
from . import views

urlpatterns=[
    path('',views.homepage,name='homepage'),
    path('<str:chamber>/',views.chamber,name='chamber'),
    path('checkview',views.checkview,name='checkview'),
    path('checkmes',views.checkmes,name='checkmes'),
    path('getMessages/<str:chamber>/',views.getMessages,name='getMessages')
] 