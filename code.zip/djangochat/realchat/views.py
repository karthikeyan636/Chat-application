from django.shortcuts import render,redirect
from realchat.models import Chamber,Message
from django.http import HttpResponse,JsonResponse
# Create your views here.
def homepage(request):
    return render(request,'homepage.html')

def chamber(request,chamber):
    username=request.GET.get('username')
    chamber_details=Chamber.objects.get(name=chamber)
    return render(request,'chamberpage.html',{
        'username':username,
        'chamber':chamber,
        'chamber_details':chamber_details,
    })

def checkview(request):
    chamber=request.POST['chamber_name']
    username=request.POST['username']
    if Chamber.objects.filter(name=chamber).exists():
        return redirect('/'+chamber+'/?username='+username)
    else:
        new_chamber=Chamber.objects.create(name=chamber)
        new_chamber.save()
        return redirect('/'+chamber+'/?username='+username)

def checkmes(request):
    chamber_id=request.POST['chamber_id']
    username=request.POST['username']
    message=request.POST['message']
    new_message=Message.objects.create(value=message,user=username,chamber=chamber_id)
    new_message.save()
    return HttpResponse('Message sent successfully')

def getMessages(request,chamber):
    chamber_details = Chamber.objects.get(name=chamber)
    messages = Message.objects.filter(chamber=chamber_details.id)
    return JsonResponse({"messages":list(messages.values())})